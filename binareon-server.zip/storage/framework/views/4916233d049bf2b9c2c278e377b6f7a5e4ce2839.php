<!DOCTYPE html>
<html lang="es">
<body>

    <div>
        <h3>Información de Contacto</h3>
        <p><strong>Nombre:</strong> <?php echo e($email['name']); ?></p>
        <p><strong>Organización:</strong> <?php echo e($email['organization']); ?></p>
        <p><strong>Cargo:</strong> <?php echo e($email['rolUser']); ?></p>
        <p><strong>Celular:</strong> <?php echo e($email['phone']); ?></p>
        <p><strong>Correo:</strong> <?php echo e($email['email']); ?></p>
    </div>
    <div>
        <h3>Mensaje</h3>
        <p><?php echo e($email['message']); ?></p>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\binareon-server\resources\views/mail/message.blade.php ENDPATH**/ ?>